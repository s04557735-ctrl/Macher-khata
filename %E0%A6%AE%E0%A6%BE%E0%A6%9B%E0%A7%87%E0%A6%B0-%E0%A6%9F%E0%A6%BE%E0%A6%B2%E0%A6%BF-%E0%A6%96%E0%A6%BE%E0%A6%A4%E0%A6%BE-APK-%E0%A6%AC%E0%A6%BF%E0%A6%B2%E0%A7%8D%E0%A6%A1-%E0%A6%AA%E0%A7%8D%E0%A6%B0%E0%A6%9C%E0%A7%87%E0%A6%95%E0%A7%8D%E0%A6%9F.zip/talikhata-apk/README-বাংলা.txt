মাছের টালি খাতা — Android APK বানানোর ফাইল

এই প্যাকেজে আপনার HTML অ্যাপটি Capacitor দিয়ে Android APK বানানোর জন্য সাজানো হয়েছে। APK এখানে আগে থেকে তৈরি নেই; GitHub Actions দিয়ে বিনামূল্যে build করতে হবে।

মোবাইল থেকে করণীয়:
১) ZIP ফাইলটি Extract করুন।
২) github.com এ লগইন করে New repository তৈরি করুন। নাম দিন mach-tali-khata এবং Public রাখুন (GitHub Actions-এর বিনামূল্যের সুবিধার জন্য)।
৩) Extract করা ফোল্ডারের ভেতরের সব ফাইল ও .github ফোল্ডারসহ repository-র মূল জায়গায় upload করুন। www/index.html ফাইলটি অবশ্যই থাকবে।
৪) ফাইল upload/commit হওয়ার পর repository-র Actions ট্যাবে যান।
৫) বাম পাশে Build Android APK workflow নির্বাচন করে Run workflow চাপুন। না দেখালে repository-র Actions tab refresh করুন।
৬) Build শেষ হলে সবুজ Success দেখাবে। ওই run খুলে নিচের Artifacts থেকে Mach-Tali-Khata-APK ডাউনলোড করুন।
৭) ZIP extract করে app-debug.apk চাপুন এবং Install দিন। Android-এ প্রয়োজন হলে “Install unknown apps” অনুমতি দিন।

নোট:
- এটি Debug APK; নিজের ফোনে ইনস্টল/পরীক্ষার জন্য। Play Store-এ প্রকাশের জন্য আলাদা signed release build লাগবে।
- অ্যাপের ডাটা WebView-এর local storage-এ থাকবে। অ্যাপ uninstall বা app data clear করলে ডাটা হারাতে পারে; নিয়মিত backup রাখা জরুরি।
- বাংলা ফন্ট লোডের জন্য প্রথমবার ইন্টারনেট লাগতে পারে।
